require("dotenv").config();
require("./config/database").connect();
const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = require("./model/user");
const auth = require("./middleware/auth");

const app = express();
app.use(express.json({ limit: "50mb" }));

class UsuarioInfo {
    constructor() {}

    set Nombres(Nombres) {
        this._Nombres = Nombres;
    }

    set Apellidos(Apellidos) {
        this._Apellidos = Apellidos;
    }

    set Email(Email) {
        this._Email = Email;
    }

    set ID_Estudiante(ID_Estudiante) {
        this._ID_Estudiante = ID_Estudiante;
    }

    set Ultima_conexion(Ultima_conexion) {
        this._Ultima_conexion = Ultima_conexion;
    }

    set Disponibilidad(Disponibilidad) {
        this._Disponibilidad = Disponibilidad;
    }

    get Nombre() {
        return this._Nombre;
    }

    get Apellidos() {
        return this._Apellidos;
    }

    get Email() {
        return this.Email;
    }

    get ID_Estudiante() {
        return this.ID_Estudiante;
    }

    get Ultima_conexion() {
        return this.Ultima_conexion;
    }

    get Disponibilidad() {
        return this._Disponibilidad;
    }
}
var usuariosList = [];

app.post("/register", async(req, res) => {
    try {
        // Get user input
        const { first_name, last_name, email, password } = req.body;

        // Validate user input
        if (!(email && password && first_name && last_name)) {
            res.status(400).send("All input is required");
        }

        // check if user already exist
        // Validate if user exist in our database
        const oldUser = await User.findOne({ email });

        if (oldUser) {
            return res.status(409).send("User Already Exist. Please Login");
        }

        //Encrypt user password
        encryptedPassword = await bcrypt.hash(password, 10);

        // Create user in our database
        const user = await User.create({
            first_name,
            last_name,
            email: email.toLowerCase(), // sanitize: convert email to lowercase
            password: encryptedPassword,
        });

        // Create token
        const token = jwt.sign({ user_id: user._id, email },
            process.env.TOKEN_KEY, {
                expiresIn: "2h",
            }
        );
        // save user token
        user.token = token;

        // return new user
        res.status(201).json(user);
    } catch (err) {
        console.log(err);
    }
});

app.post("/login", async(req, res) => {
    //logica de login va aqui
    try {
        const { email, password } = req.body;

        if (!(email && password)) {
            res.status(400).send("todos los campos son requeridos");
        }

        //validamos si existe el usuario 
        const user = await User.findOne({ email });

        if (user && (await bcrypt.compare(password, user.password))) {
            //if (user && (password == user.password)) {
            const token = jwt.sign({ user_id: user._id, email },
                process.env.TOKEN_KEY, {
                    expiresIn: "1h",
                    //expiresIn: 60,
                }
            );

            user.token = token;
            res.status(200).json(user);
            return;
        }

        res.status(400).send("Credenciales Incorrectas");

    } catch (error) {
        console.log(`Ocurrio un error en el login ${error}`)
    }
});

app.get("/bienvenido", auth, (req, res) => {
    res.status(200).send("Welcome 🙌 ");
});

app.post("/cargarEstudiantes", auth, async(req, res) => {
    const csv = require('csvtojson');
    const converter = csv()
        .fromFile('asserts/Carga_Estudiantes.csv')
        .then(async(json) => {
            let usuarioItem;
            json.forEach((row) => {
                usuarioItem = new UsuarioInfo();

                Object.assign(usuarioItem, row);
                usuariosList.push(usuarioItem);
            });
        }).then(async() => {
            usuariosList.forEach(async(usuarioRow) => {
                const oldUser = await User.findOne({ email: usuarioRow._Email });

                if (oldUser) {
                    console.log("El usuario " + usuarioRow._Email + " ya existe en la base de datos");
                } else {
                    const user = User.create({
                        id_estudiante: usuarioRow._ID_Estudiante,
                        nombre: usuarioRow._Nombres,
                        apellido: usuarioRow._Apellidos,
                        email: usuarioRow._Email.toLowerCase()
                    })
                }
            });
            usuariosList = [];
            res.status(200).send("Usuarios Creados Satisfactoriamente");
        });
})

// This should be the last route else any after it won't work
app.use("*", (req, res) => {
    res.status(404).json({
        success: "false",
        message: "Page not found",
        error: {
            statusCode: 404,
            message: "You reached a route that is not defined on this server",
        },
    });
});

module.exports = app;