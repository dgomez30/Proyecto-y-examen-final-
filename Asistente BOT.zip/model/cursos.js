const mongoose = require('mongoose');

const cursoSchema = new mongoose.Schema({
    id_estudiante: { type: String, unique: true },
    curso_asignado: { type: String }
});
module.exports = mongoose.model("cursos", cursoSchema);