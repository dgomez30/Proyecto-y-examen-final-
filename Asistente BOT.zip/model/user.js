const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
    id_estudiante: { type: String, default: null },
    nombre: { type: String, default: null },
    apellido: { type: String, default: null },
    email: { type: String, unique: true },
    password: { type: String, default: "" },
    disponibilidad: { type: String, default: "SI" },
    ultima_conexion: { type: Date, default: new Date(+new Date() + 7 * 24 * 60 * 60 * 1000) },
    token: { type: String },
});

module.exports = mongoose.model("usuarios", userSchema);